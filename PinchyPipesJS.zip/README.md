# GoofusDoofus

Live @ [https://main.d3rkoi6jt7fy7l.amplifyapp.com/](https://main.d3rkoi6jt7fy7l.amplifyapp.com/)
  
  
F u mike 
