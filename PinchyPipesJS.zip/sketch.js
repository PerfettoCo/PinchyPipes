let canvasHeight = 800;
let obsMaxHeight = 0.35 * canvasHeight;
let obsWidth = 25;
let gravity = 5;
let obstSpacing = 150;
var gameover = false;
let skysky;
let birdasset;
let birdmask;
let floorasset;
let pipeupasset;
let pipedownasset;
let planeupasset;
let planedownasset;
let planeleftasset;
let planerightasset;

var nextTick=0;


var bg;
var bird = {x: 400, y: 400, rad: 15, speed: 1, health: 100, offx: 0, injured: 0};


function preload() {
      skysky = loadImage('skybackground.bmp');
      birdasset = loadImage('bird.png');
      birdmask = loadImage('birdmask.png');
      floorasset = loadImage('floor.bmp');
      pipeupasset = loadImage('uppipe.png');
      pipedownasset = loadImage('downpipe.png');
      planeleftasset = loadImage('planeleft.bmp');
      planerightasset = loadimage('planeright.bmp');
      planeupasset = loadimage('planeup.bmp');
      planedownasset = loadimage('planedown.bmp');
      //birdasset.mask(birdmask);
      //image(birdasset,0,0);

      
  }

class Obstacle {
    constructor(x, height, ceiling) {
        this.x = x;
        this.height = height;
        this.ceiling = ceiling;
        this.color = color(25,255,25);
        
    }

    isCollided(x,y) {
        let topLeft = {x: this.x, y: this.ceiling===true ? 0 : canvasHeight - this.height};
        let bottomRight = {x: topLeft.x + obsWidth, y: topLeft.y + this.height};
        if (x < bottomRight.x && x > topLeft.x 
            && y > topLeft.y && y < bottomRight.y) {
            this.color = color(255,0,0);
            return true;
        }
        return false;
    }

    draw() {
        fill(this.color);
        if (this.ceiling === true) {
            rect(this.x - bird.x, 0, obsWidth, this.height);
            image(pipedownasset, this.x - bird.x, 0, obsWidth, this.height);
        } else {
            rect(this.x - bird.x, canvasHeight - this.height, obsWidth, this.height);
            image(pipeupasset,this.x-bird.x,canvasHeight-this.height, obsWidth, this.height);
        }
    }
};

class Plane {
    constructor(x, height, ceiling) {
        this.x = x;
        this.y = 200;
        this.height = height;
        this.Active= ceiling;
        this.color = color(25,255,25);
        this.dead = false;
        
    }

    isCollided(x,y) {
        let topLeft = {x: this.x, y: this.ceiling===true ? 0 : canvasHeight - this.height};
        let bottomRight = {x: topLeft.x + obsWidth, y: topLeft.y + this.height};
        if (x < bottomRight.x && x > topLeft.x 
            && y > topLeft.y && y < bottomRight.y) {
            this.color = color(255,0,0);
            return true;
        }
        return false;
    }

    draw() {
        fill(this.color);
        if (this.dead===false) {
            //rect(this.x - bird.x, 0, obsWidth, this.height);
            image(planeleftasset, this.x - bird.x, this.y, obsWidth, 20);
        } else {
           // rect(this.x - bird.x, canvasHeight - this.height, obsWidth, this.height);
          //  image(plaedownasset,this.x-bird.x,canvasHeight-this.height, obsWidth, this.height);
        }
    }
};


class Background {
    constructor() {
        this.obsts = [];
        this.Planes = [];
        this.lastObstX = 0;
        this.lastPlaneX = 0;
        for (var i = 0; i < 10; i++) {
            this.genObst();
            this.genPlane();
        }
    }

    genObst() {
        this.obsts.push(new Obstacle(this.lastObstX, random()*obsMaxHeight, true));
        this.obsts.push(new Obstacle(this.lastObstX, random()*obsMaxHeight, false));
        this.lastObstX += obstSpacing;
    }

    genPlane() {
        this.Planes.push(new Plane(this.lastPlaneX, random()*obsMaxHeight, true));
        this.lastPlaneX += obstSpacing;
    }
    

    draw() {


        if(!gameover) {
        //skysky.addEventListener('input',updateValue);
        background(0);
        var scrollX = (bird.x/4) % (skysky.width/2);
        var gscrollX = (bird.x/3    ) % (floorasset.width/2);
        image(skysky,    0,                  0,       900, canvasHeight, scrollX, 0, skysky.width/2, skysky.height); 
        image(floorasset,0, canvasHeight-50, 900, 50, gscrollX, 0, floorasset.width/2);
       // if(MouseEvent.keyPressed){bird.health=0;}
       //image(floorasset,0,0,40,40);

        //var ScrollX =  bird.x-900;
        //    image(skysky, 0, 0, 800, canvasHeight, 100/ScrollX, 0, 100, 0, 0);
        this.obsts.forEach(obs => {
            obs.draw()
        })
        

        this.Planes.forEach(pln => {
            pln.draw()
        })

        if (this.obsts[0].x < bird.x - 450) {
            this.obsts.shift();
            this.genObst();
        }

        if (this.Planes[0].x < bird.x - 450) {
            this.Planes.shift();
            this.genPlane();
        }    
    
        redraw()
    }
    else { drawgameover(); }

    }
};
function drawgameover() {

    background(0);
    fill(0,0,0);
    rect(0,0,500,500);

    
    redraw();
}

function updateValue(e) {
    
  bird.health = 100;
}

function setup() {
    createCanvas(900, canvasHeight);
    bg = new Background();
    //birdasset.mask(birdmask);
    //image(birdasset,0,0);
    
    
}

//function keyReleased() {
//    if (keyCode === UP_ARROW) {
//        bird.y -= 80;
//        redraw();
//    }
//}

function keyPressed() {
      if (keyIsDown(UP_ARROW)) {
       // bird.y -= 80;
        redraw();

    }
}


function mousePressed(e) {
    if(!bird.injured)bird.y-=80;
 
  redraw();

}

function touchstarted(e) {
    bird.health = 70;
    bird.y-=80;
    redraw();


}
function touchmoved(e) {
    bird.health+=10;
    gameover=true;
    redraw();
}
function touchend(e) {
    gameover=true;
   bird.health = 100;
   redraw();
}

function onTouch(evt)  {
    switch (evt.type) {
        case "touchstart": 
        bird.health = 95;
          type = "mousedown";
          touch = evt.changedTouches[0];
          break;
        case "touchmoved":
            bird.health+=10;
            gameover=true;
            break;
          type = "mousemove";
          touch = evt.changedTouches[0];
          break;
        case "touchend":   
        bird.health = 1115;     
          type = "mouseup";
          touch = evt.changedTouches[0];
          break;
      }
      redraw();

}


function drawBird() {

    fill(color(0,0,0));
    noStroke();

    //birdasset.mask(birdmask);
    image(birdasset,450+bird.offx,bird.y);   
        //circle(450, bird.y, bird.rad);

    if(bird.y < canvasHeight-75||gameover) { bird.y += gravity; }
    if(bird.y >= canvasHeight-85) { bird.injured = 0; }
    bird.x += bird.speed;
}

function checkCollision() {
    for(var i = 0; i < bg.obsts.length; i++) {
        if (bg.obsts[i].isCollided(bird.x + (450+bird.offx), bird.y))
            return true;
    };
    return false;
}

// function gameOver() {
//     print("Game Over");
// }

function draw() {

    if(!bird.injured){
    if (keyIsDown(UP_ARROW) && bird.y > 25 && Date.now() >= nextTick) {
        bird.y -= 40;
        nextTick= Date.now()+50;
        redraw();
    }
    if(keyIsDown(LEFT_ARROW) && Date.now() >= nextTick)
    {
          bird.speed--;
          nextTick= Date.now()+50;
    }
    if(keyIsDown(RIGHT_ARROW) && Date.now() >= nextTick)
    {
        if(!checkCollision()) {
          bird.speed++;
          if(bird.offx > 0) {

          nextTick= Date.now()+50;
          }
          else { if(!checkCollision()) bird.offx = bird.offx + bird.speed; }
        }
    }
  }
    if (gameover === false) {
    bg.draw();
    drawBird();

  
    var w = (bird.health*200)/100 - 2; 
    //draw health
    fill(color(0,0,0));
    rect(0,0,200,20);
    fill(color(255,0,0));
    rect(1,1,w,18);   
    //skyasset.draw();
    if (checkCollision()){
        bird.health = bird.health - 20;
        bird.offx = -100;
        bird.speed = 0;
        bird.injured = 1;
        if(bird.health < 10)gameover=true;
    }
     }
     else {
         background(50);
         document.write("YOU SUCK ");
     }
    
}
